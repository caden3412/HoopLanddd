'use client'

export default function Home() {
  return <div>Welcome to HoopLand Scout</div>
}